<?php

$manifest = array (
  'key' => 'base_2306.builds.20200430100139',
  'name' => 'bp_atlas_6107_2306',
  'description' => 'base_2306.builds.20200430100139 - see README for details',
  'author' => 'SugarCRM Professional Services',
  'readme' => 'README',
  'is_uninstallable' => true,
  'published_date' => '2020-04-30 10:01:39',
  'type' => 'module',
  'version' => '1.0',
  'acceptable_sugar_versions' => 
  array (
    'regex_matches' => array('(.*?)\.(.*?)\.(.*?)$'),
  ),
);

$installdefs = array (
  'id' => 'base_2306.builds.20200430100139',
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/files/custom/modules/Accounts/clients/base/api/CustomAccountsApi.php',
      'to' => 'custom/modules/Accounts/clients/base/api/CustomAccountsApi.php',
    ),
  ),
);