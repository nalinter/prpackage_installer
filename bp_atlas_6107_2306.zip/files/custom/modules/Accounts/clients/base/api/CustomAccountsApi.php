<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}
require_once("clients/base/api/ModuleApi.php");
require_once('include/SugarHttpClient.php');
use \Sugarcrm\Sugarcrm\Security\Crypto\Blowfish;
class CustomAccountsApi extends ModuleApi
{
    use \Sugarcrm\Sugarcrm\custom\Api\SocIdTrait;
    use \Sugarcrm\Sugarcrm\custom\Api\AIMTrait;
    protected $relogin;
    protected $findCmrUrl;
    protected $createCMRView;
    public function registerApiRest()
    {
        return [
            'findCmrFromRdc' => [
                'reqType' => 'POST',
                'path' => ['Accounts', 'findCmr'],
                'pathVars' => ['module', 'type'],
                'method' => 'findCmrFromRdc',
                'shortHelp' => 'Find a CMR from RDC',
            ],
            'importAccount' => [
                'reqType' => 'POST',
                'path' => ['Accounts', 'importAccount'],
                'pathVars' => ['module'],
                'method' => 'importAccount',
                'shortHelp' => 'This method creates a new record of the specified type',
            ],
            'opptyLinkage' => [
                'reqType' => 'POST',
                'path' => ['Accounts', 'opptyLinkage'],
                'pathVars' => ['module'],
                'method' => 'linkRelatedOppty',
                'shortHelp' => 'Correct Account Opportunity linkage',
            ],
            'createCMRAccount' => [
                'reqType' => 'POST',
                'path' => ['Accounts', 'createCMRAccount'],
                'pathVars' => ['module'],
                'method' => 'createCMRAccount',
                'shortHelp' => 'This method creates a new record of the specified type',
            ],
        ];
    }

    /**
     * Gets the full tree data in a jstree structure
     * @param ServiceBase $api
     * @param array $args
     * @return stdClass
     */
    public function findCmrFromRdc(ServiceBase $api, array $args)
    {
        global $sugar_config, $mod_strings, $app_list_strings;
        $this->createCMRView = false;
        $rdc_secret = Blowfish::decode(
            Blowfish::getKey('custom_encrypt_key'),
            $sugar_config['rdc_integration_client_secret']
        );
        $this->host = $sugar_config['rdc_integration_search_url'];
        $this->oauthConfig = json_encode(['client_id' => $sugar_config['rdc_integration_client_id'],
                              'client_secret' => $rdc_secret,
                              'grant_type' => $sugar_config['rdc_integration_grant_type']]);
        $data = ['name'=> '',
                 'billing_address_country' => '',
                 'billing_address_state' => '',
                 'billing_address_postalcode' => '',
                 'billing_address_city' => '',
                 'billing_address_street' => '',
                 'cmr_number' => '',
                 'issuing_country' => '',
                 'source' => 'bp'];

        $args['searchType'] = $args['searchType'] ? $args['searchType'] : 'number';
        if ($args['searchType'] == 'number') {
            if (empty($args['cmr_number']) && empty($args['issuing_country'])) {
                return $this->getErrorResponse($mod_strings['LBL_FIND_CMR_PARAME_ERROR']);
            }
            $data['cmr_number'] = $args['cmr_number'];
            $data['issuing_country'] = $args['issuing_country'];
            $this->createCMRView = true;
        } else {
            if (empty($args['cmr_name']) && empty($args['address_country'])) {
                return $this->getErrorResponse($mod_strings['LBL_FIND_CMR_PARAME_ERROR']);
            }
            $data['name'] = $args['cmr_name'];
            $data['billing_address_country'] = $args['address_country'];
            if (!empty($args['createCMR']) && $args['createCMR'] === true) {
                $data['name'] = $args['cmr_name'];
                $data['billing_address_country'] = $args['address_country'];
                $data['billing_address_state'] = $app_list_strings['state_iso_code'][$args['address_state']]['state'];
                $data['billing_address_postalcode'] = $args['address_postal_code'];
                $data['billing_address_city'] = $args['address_city'];
                $data['billing_address_street'] = $args['address_street'];
                $this->createCMRView = true;
            }
        }

        $response = $this->getCMR($data);
        return $response;
    }
    private function getCMR($data)
    {
        global $mod_strings;
        if (!$this->validateOauthToken()) {
            return $this->getErrorResponse($mod_strings['LBL_FIND_CMR_CONNECT_ERROR']);
        }
        $dataJson = json_encode($data);
        $response = $this->search($dataJson);
        if (!is_array($response)) {
            $result = json_decode($response);
        }
        if (!empty($result->errors)) {
            return $result->errors;
        }
        $result = $this->formatRdcFields($result);
        return $result;
    }

    public function validateOauthToken()
    {
        if (empty($this->token)) {
            $token = $this->oauth();
            $tokenArray = json_decode($token, true);
            if (!empty($tokenArray['errors']) || empty($tokenArray['access_token'])) {
                return false;
            }
            $this->token = $tokenArray['access_token'];
            if ($this->token === false) {
                return false;
            }
        }
        return true;
    }

    private function formatRdcFields($result)
    {
        global $app_list_strings;
        $formatRdcFields = array(
            'industry_name' => 'industry_dom',
            'indus_isu_name' => 'indus_isu_name_c_list',
            'indus_sic_name' => 'indus_sic_code_c_list',
            'billing_address_country' => 'address_country_list',
            'billing_address_state' => 'address_state_list',
        );
        $reMapFields = array(
            'industry' => 'industry_name',
            'indus_isu_name_c' => 'indus_isu_name',
            'indus_sic_code_c' => 'indus_sic_name',
            'billing_address_country' => 'billing_address_country_c',
            'billing_address_state' => 'billing_address_state_c',
        );
        $moveFields = array(
            'shipping_address_country',
            'shipping_address_state',
            'shipping_address_city',
            'shipping_address_street',
            'shipping_address_postalcode',
            'duns_num',
            'security_class_code',
            'industry',
            'indus_isu_name_c',
            'indus_sic_code_c',
            'industry_class_c',
        );
        if (gettype($result) == 'object'){
            $result = (array)$result;
        }
        if ($result['records']) {
            if (count($result['records']) > 10) {
                $result['records'] = array_slice($result['records'], 0, 10);
            }
            foreach ($result['records'] as $key => $value) {
                $countryCode = $value->billing_address_country;
                $result['records'][$key] = (array)$result['records'][$key];

                if ($this->createCMRView) {
                    $cmrBeanExists = BeanFactory::getBean('Accounts')->retrieve_by_string_fields(
                        [
                            'mpp_num_c' => $result['records'][$key]['mpp_num_c'],
                            'account_type' => 'C'
                        ]
                    );
                    if (!empty($cmrBeanExists)) {
                        $result['records'][$key]['account_source'] = 'ATLAS';
                        $result['records'][$key]['id'] = $cmrBeanExists->id;
                    } else {
                        $result['records'][$key]['account_source'] = 'RDC';
                    }
                }
                foreach ($reMapFields as $k => $val) {
                    if ($val == 'billing_address_state_c') {
                        $value->$k = $this->getExactMatchStateCode($value->$k, $countryCode);
                    }
                    $result['records'][$key][$val] = $value->$k; 
                    $value->$val = $value->$k;
                }
                $result['records'][$key]['import_data'] = array (
                    'deleted' => false,
                    'created_by' => $current_user->id,
                    'name' => $result['records'][$key]['client_name_c'],
                    'cmr_number_c' => $result['records'][$key]['cmr_number_c'],
                    'mpp_num_c' => $result['records'][$key]['mpp_num_c'],
                    'issuing_country_c' => $result['records'][$key]['issuing_country_c'],
                    'cov_id_c' => $result['records'][$key]['cov_id_c'],
                    'billing_address_country' => $result['records'][$key]['billing_address_country_c'],
                    'billing_address_state' => $result['records'][$key]['billing_address_state_c'],
                    'billing_address_postalcode' => $result['records'][$key]['billing_address_postalcode'],
                    'billing_address_city' => $result['records'][$key]['billing_address_city'],
                    'billing_address_street' => $result['records'][$key]['billing_address_street'],
                    'api_source_c' => 'rdc',
                    'indus_sic_code_c' => $result['records'][$key]['indus_sic_name'],
                    'indus_isu_name_c' => $result['records'][$key]['indus_isu_name'],
                    'industry' => $result['records'][$key]['industry_name'],
                    'client_id_c' => $result['records'][$key]['client_id_c'],
                    'global_account_id_c' => $result['records'][$key]['gb_id_c'],
                    'global_account_name_c' => $result['records'][$key]['gb_name_c'],
                    'account_type' => empty($result['records'][$key]['gb_id_c']) ? 'D' : 'B',
                );
                foreach ($value as $k => $val) {
                    if (!empty($formatRdcFields[$k])) {
                        $result['records'][$key][$k] = $app_list_strings[$formatRdcFields[$k]][$val];
                    }
                    if (in_array($k, $moveFields)) {
                        unset($result['records'][$key][$k]);
                    }
                }
                $result['records'][$key]['cmr_address_c'] =
                    $result['records'][$key]['billing_address_country'] . " " .
                    $result['records'][$key]['billing_address_state'] . " " .
                    mb_ereg_replace('(([ \r\n\t])*(　)*)*$', '', $result['records'][$key]['billing_address_city']) . " " .
                    mb_ereg_replace('(([ \r\n\t])*(　)*)*$', '', $result['records'][$key]['billing_address_street']) . " " .
                    $result['records'][$key]['billing_address_postalcode'];
            }
        }
        return $result;
    }
    private function getExactMatchStateCode($state, $country)
    {
        if (empty($country) || empty($state)) {
            return '';
        }
        global $app_list_strings;
        $stateList = $app_list_strings['state_list_hierarchy'][$country];
        if (empty($stateList) || count($stateList) == 0) {
            return '';
        }
        foreach ($stateList as $item) {
            if (strpos($item, $state) === 0) {
                return $item;
            }
        }
        return '';
    }
    private function getErrorResponse($message)
    {
        $response = array(
            "records" => "",
            "error_message" => $message
        );
        return $response;
    }
    public function importAccount(ServiceBase $api, array $args)
    {
        global $sugar_config;
        $accountBean = '';
        $cmrBean = '';
        $result = ['account_id' => '',
                   'account_name' => '',
                   'cmr_account_id' => '',
                   'cmr_account_name' => ''];
        if (!empty($args[0]['dc'])
            && !empty($args[0]['dc']['client_id_c'])
            && $args[0]['dc']['client_id_c'] != $sugar_config['dummy_account_id']) {
            $accountBean = BeanFactory::getBean('Accounts')->retrieve_by_string_fields(
                            array(
                                'client_id_c' => $args[0]['dc']['client_id_c'],
                                'deleted' => 0
                            )
                        );
        }
        if (empty($accountBean)) {
            if (empty($args[0]['dc']['client_id_c'])
                || $args[0]['dc']['client_id_c'] == $sugar_config['dummy_account_id']) {
                if (!empty($args[0]['dc']['mpp_num_c'])) {
                    $accountBean = BeanFactory::getBean('Accounts')->retrieve_by_string_fields(
                        [
                            'mpp_num_c' => $args[0]['dc']['mpp_num_c'],
                            'deleted' => 0,
                            'account_type' => 'B'
                        ]
                    );
                } else {
                    $args[0]['dc']['client_id_c'] = $sugar_config['dummy_account_id'];
                    $args[0]['dc']['account_type'] = 'B';
                }
            }
            if (empty($accountBean)) {
                $args[0]['dc']['module'] = 'Accounts';
                $_SESSION['rdcImportAccess'] = true;
                $accountBean = (object) parent::createRecord($api, $this->getWithSocIds($args[0]['dc']));
            }
        }
        $result['account_id']   = !empty($accountBean->id) ? $accountBean->id : '';
        $result['account_name'] = !empty($accountBean->name) ? $accountBean->name : '';
        if (!empty($args[1]['cmr']) && !empty($args[1]['cmr']['mpp_num_c']) && !empty($accountBean->id)) {
            $cmrBean = BeanFactory::getBean('Accounts')->retrieve_by_string_fields(
                            array(
                                'mpp_num_c' => $args[1]['cmr']['mpp_num_c'],
                                'deleted' => 0,
                                'account_type' => 'C'
                            )
                        );
            if (empty($cmrBean)) {
                if ($args[0]['dc']['api_source_c'] == 'rdc' && !empty($args[1]['cmr']['cmr_num_c'])) {
                    $_SESSION['rdcImportAccess'] = true;
                }
                $cmrArgs = $this->buildCMRforImport($args, $result['account_id']);
                $cmrBean = (object) parent::createRecord($api, $this->getWithSocIds($cmrArgs));
            }
            $result['cmr_account_id']   = !empty($cmrBean->id) ? $cmrBean->id : '';
            $result['cmr_account_name'] = !empty($cmrBean->id) ? $cmrBean->name : '';
        }
        return $result;
    }

    public function createCMRAccount(ServiceBase $api, array $args)
    {
        global $sugar_config;
        $accountBean = '';
        $cmrBean = '';
        $result = ['account_id' => '',
                    'account_name' => '',
                    'cmr_account_id' => '',
                    'cmr_account_name' => '',
                    'client_id_c' => $sugar_config['dummy_account_id'],
                    'module' => 'Accounts',
                    'account_type' => '',
                    'api_source_c'=>''];
        if (!empty($args[0]['dc']) && !empty($result['client_id_c'])) {
            $_SESSION['rdcImportAccess'] = true;
            $result['account_type'] = 'B';
            $dcCreate = $this->buildProspectAccount($args[0]['dc'], $result);
            $accountBean = (object) parent::createRecord($api, $this->getWithSocIds($dcCreate));
        }
        $result['account_id']   = !empty($accountBean->id) ? $accountBean->id : '';
        $result['account_name'] = !empty($accountBean->name) ? $accountBean->name : '';
        if (!empty($args[1]['cmr']) && !empty($accountBean->id)) {
            $_SESSION['rdcImportAccess'] = true;
            $result['client_id_c'] = '';
            $result['account_type'] = 'C';
            $result['api_source_c'] = 'prospect';
            $cmrCreate = $this->buildProspectAccount($args[1]['cmr'], $result);
            $cmrBean = (object) parent::createRecord($api, $this->getWithSocIds($cmrCreate));
            $result['cmr_account_id']   = !empty($cmrBean->id) ? $cmrBean->id : '';
            $result['cmr_account_name'] = !empty($cmrBean->id) ? $cmrBean->name : '';
        }
        return $result;
    }

    public function buildProspectAccount($accountArgs, $accountValues)
    {
        $account = [];
        $account['name'] = $accountArgs['cmr_name_c'];
        $account['client_id_c'] = $accountValues['client_id_c'];
        $account['billing_address_country'] = $accountArgs['cmr_country_c'];
        $account['billing_address_state'] = $accountArgs['cmr_state_c'];
        $account['billing_address_postalcode'] = $accountArgs['cmr_postalcode_c'];
        $account['billing_address_city'] = $accountArgs['cmr_city_c'];
        $account['billing_address_street'] = $accountArgs['cmr_street_c'];
        $account['indus_sic_code_c'] = $accountArgs['indus_sic_code_c'];
        $account['indus_isu_name_c'] = $accountArgs['indus_isu_name_c'];
        $account['industry'] = $accountArgs['industry'];
        $account['industry_class_c'] = $accountArgs['industry_class_c'];
        $account['account_type'] = $accountValues['account_type'];
        $account['module'] = $accountValues['module'];
        $account['parent_id'] = $accountValues['account_id'];
        if (isset($accountArgs['non_latin_language'])
        && $accountArgs['non_latin_language'] === true) {
            $account['sub_lang_code_c'] = $accountArgs['sub_lang_code'];
        }
        $account['api_source_c'] = $accountValues['api_source_c'];
        return $account;
    }

    public function buildCMRforImport($cmrArgs, $dc)
    {
        $crm = [];
        $cmr['name'] = $cmrArgs[1]['cmr']['cmr_name_c'];
        $cmr['client_id_c'] = $cmrArgs[1]['cmr']['cmr_num_c'].'-'.$cmrArgs[0]['dc']['issuing_country_c'];
        $cmr['cmr_number_c'] = $cmrArgs[1]['cmr']['cmr_num_c'];
        $cmr['mpp_num_c'] = $cmrArgs[1]['cmr']['mpp_num_c'];
        $cmr['issuing_country_c'] = $cmrArgs[0]['dc']['issuing_country_c'];
        $cmr['cov_id_c'] = $cmrArgs[0]['dc']['cov_id_c'];
        $cmr['billing_address_country'] = $cmrArgs[1]['cmr']['cmr_country_c'];
        $cmr['billing_address_state'] = $cmrArgs[1]['cmr']['cmr_state_c'];
        $cmr['billing_address_postalcode'] = $cmrArgs[1]['cmr']['cmr_postalcode_c'];
        $cmr['billing_address_city'] = $cmrArgs[1]['cmr']['cmr_city_c'];
        $cmr['billing_address_street'] = $cmrArgs[1]['cmr']['cmr_street_c'];
        $cmr['api_source_c'] = $cmrArgs[0]['dc']['api_source_c'];
        $cmr['indus_sic_code_c'] = $cmrArgs[0]['dc']['indus_sic_code_c'];
        $cmr['indus_isu_name_c'] = $cmrArgs[0]['dc']['indus_isu_name_c'];
        $cmr['industry'] = $cmrArgs[0]['dc']['industry'];
        $cmr['account_type'] = 'C';
        $cmr['parent_id'] = $dc;
        $cmr['module'] = 'Accounts';
        return $cmr;
    }
    public function linkRelatedOppty(ServiceBase $api, array $args)
    {
        global $db;
        $accountInfo = [];
        $result = [];
        if(empty($args['old_cmr_id'])
            && empty($args['new_cmr_id'])
            && empty($args['old_dc_id'])
            && empty($args['new_dc_id'])) {
            $result['error'] = true;
            return $result;
        }

        $accountInfo['id']          = create_guid();
        $accountInfo['old_cmr_id']  = !empty($args['old_cmr_id']) ? $args['old_cmr_id'] : "";
        $accountInfo['new_cmr_id']  = !empty($args['new_cmr_id']) ? $args['new_cmr_id'] : "";
        $accountInfo['old_dc_id']   = !empty($args['old_dc_id']) ? $args['old_dc_id'] : "";
        $accountInfo['new_dc_id']   = !empty($args['new_dc_id']) ? $args['new_dc_id'] : "";
        $accountInfo['dc_deleted']  = !empty($args['dc_deleted']) ? $args['dc_deleted'] : 0;
        $accountInfo['cmr_deleted'] = !empty($args['cmr_deleted']) ? $args['cmr_deleted'] : 0;

        $sql = "SELECT id FROM accounts_opportunity_relink
                WHERE old_cmr_id = ".$db->quoted($accountInfo['old_cmr_id'])."
                AND new_cmr_id = ".$db->quoted($accountInfo['new_cmr_id'])."
                AND old_dc_id = ".$db->quoted($accountInfo['old_dc_id'])."
                AND new_dc_id = ".$db->quoted($accountInfo['new_dc_id'])."
                AND dc_deleted = ".$db->quoted($accountInfo['dc_deleted'])."
                AND cmr_deleted = ".$db->quoted($accountInfo['cmr_deleted'])."
                AND deleted = 0";
        $id = $db->getOne($sql);
        if(!empty($id)) {
            $result['id'] = $id;
            return $result;
        }

        $accountInfo['date_entered'] = date("Y-m-d H:i:s");
        $accountInfo['date_modified'] =  date("Y-m-d H:i:s");

        $fields =  implode('`,`', array_keys($accountInfo));
        $fields = "`{$fields}`";
        $sql = 'INSERT INTO accounts_opportunity_relink ('.$fields.') VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)';
        $stmt = $db->getConnection()->executeQuery($sql, array_values($accountInfo));
        $result['id'] = $accountInfo['id'];
        return $result;
    }
}
